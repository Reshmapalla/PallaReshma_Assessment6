// Define the Book class
class Book {
    // Constructor to initialize properties
    constructor(title, author, publicationYear) {
        this.title = title; // Title of the book
        this.author = author; // Author of the book
        this.publicationYear = publicationYear; // Publication year of the book
    }

    // Method to display the book details
    displayDetails() {
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.publicationYear}`);
    }
}

// Example usage:

// Create a new Book object
const myBook = new Book('To Kill a Mockingbird', 'Harper Lee', 1960);

// Display the book details
myBook.displayDetails();
