function filterOddNumbers(numbers) {
    // Use the filter method to keep only the odd numbers
    return numbers.filter(function(number) {
        return number % 2 !== 0; // Return true if the number is odd
    });
}

// Example usage:
var numbersArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var oddNumbers = filterOddNumbers(numbersArray);

console.log(oddNumbers); // Output: [1, 3, 5, 7, 9]
