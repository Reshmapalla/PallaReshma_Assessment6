function squareNumbers(numbers) {
    // Use the map function to create a new array with each number squared
    return numbers.map(function(number) {
        return number * number; // Square each number
    });
}

// Example usage:
var numbersArray = [1, 2, 3, 4, 5];
var squaredNumbers = squareNumbers(numbersArray);

console.log(squaredNumbers); // Output: [1, 4, 9, 16, 25]
