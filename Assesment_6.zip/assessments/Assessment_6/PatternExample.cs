﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_6
{
    class PatternExample
    {
        static void Main(string[] args)
        {
            // Number of lines to print
            int lines = 5;

            // Loop through each line
            for (int i = 1; i <= lines; i++)
            {
                // Print numbers for the current line
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j + " ");
                }
                // Move to the next line
                Console.WriteLine();
            }
        }
    }
}
    