﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_6
{
    internal class LinqExample
    {
       
        class Program
        {
            // Define the Student class
            public class Student
            {
                public int ID { get; set; }
                public string Name { get; set; }
            }

            // Define the CourseEnrollment class
            public class CourseEnrollment
            {
                public int StudentID { get; set; }
                public string Course { get; set; }
            }

            static void Main(string[] args)
            {
                // Create a list of students
                var students = new List<Student>
            {
                new Student { ID = 1, Name = "Alice" },
                new Student { ID = 2, Name = "Bob" },
                new Student { ID = 3, Name = "Charlie" }
            };

                // Create a list of course enrollments
                var enrollments = new List<CourseEnrollment>
            {
                new CourseEnrollment { StudentID = 1, Course = "Math" },
                new CourseEnrollment { StudentID = 1, Course = "Science" },
                new CourseEnrollment { StudentID = 2, Course = "Math" },
                new CourseEnrollment { StudentID = 3, Course = "History" }
            };

                // LINQ query to retrieve students along with the courses they are enrolled in
                var studentCourses = from student in students
                                     join enrollment in enrollments
                                     on student.ID equals enrollment.StudentID
                                     group enrollment by new { student.ID, student.Name } into studentGroup
                                     select new
                                     {
                                         StudentID = studentGroup.Key.ID,
                                         StudentName = studentGroup.Key.Name,
                                         Courses = studentGroup.Select(e => e.Course).ToList()
                                     };

                // Print the results
                foreach (var student in studentCourses)
                {
                    Console.WriteLine($"Student ID: {student.StudentID}, Name: {student.StudentName}");
                    Console.WriteLine("Courses: " + string.Join(", ", student.Courses));
                    Console.WriteLine();
                }
            }
        }
    }

}

