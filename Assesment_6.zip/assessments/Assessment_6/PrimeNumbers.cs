﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_6
{
    class PrimeNumbers
    {
        // Function to check if a number is prime
        public static bool IsPrime(int number)
        {
            if (number < 2) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++) //Therefore, if we find no divisors up to sqrt(number), we won't find any divisors above sqrt(number) either.
            {
                if (number % i == 0) return false;
            }
            return true;
        }

        static void Main(string[] args)
        {
            try
            {
                // Prompt user for input
                Console.Write("Enter the number of prime numbers to generate: ");
                string input = Console.ReadLine();
                int n = int.Parse(input);

                // Validate input
                if (n <= 0)
                {
                    Console.WriteLine("Please enter a positive integer.");
                    return;
                }

                Console.WriteLine($"The first {n} prime numbers are:");

                // Generate and display the first N prime numbers
                int count = 0;
                int number = 2;

                while (count < n)
                {
                    if (IsPrime(number))
                    {
                        Console.WriteLine(number);
                        count++;
                    }
                    number++;
                }
            }
            catch (FormatException)
            {
                // Handle case where input is not a valid integer
                Console.WriteLine("Invalid input. Please enter a valid integer.");
            }
            catch (Exception ex)
            {
                // Handle any other unexpected exceptions
                Console.WriteLine($"An unexpected error occurred: {ex.Message}");
            }
        }
    }



}
