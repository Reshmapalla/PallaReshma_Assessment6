﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment_6
{
    using System;
    using System.Linq;

    class ArrayOperations
    {
        static void Main(string[] args)
        {
            try
            {
                // Sample array of integers
                int[] numbers = { 10, 20, 30, 40, 50 };

                // Find the sum of all elements
                int sum = numbers.Sum();
                Console.WriteLine($"Sum of all elements: {sum}");

                // Find the average of all elements
                double average = numbers.Average();
                Console.WriteLine($"Average of all elements: {average}");

                // Find the maximum and minimum values
                int max = numbers.Max();
                int min = numbers.Min();
                Console.WriteLine($"Maximum value: {max}");
                Console.WriteLine($"Minimum value: {min}");
            }
   
            catch (Exception ex)
            {
                // Handle any other unexpected exceptions
                Console.WriteLine($"An unexpected error occurred: {ex.Message}");
            }
        }
    }

}
