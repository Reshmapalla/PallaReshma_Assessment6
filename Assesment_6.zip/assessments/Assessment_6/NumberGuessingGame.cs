﻿namespace Assessment_6
{


    class NumberGuessingGame
    {
        static void Main(string[] args)
        {
            try
            {
                // Define the range
                int min = 1;
                int max = 100;
                int maxAttempts = 5;

                // Generate a random number within the range
                Random random = new Random();
                int numberToGuess = random.Next(min, max + 1);

                // User's guess and attempts
                int userGuess = 0;
                int attempts = 0;

                Console.WriteLine($"Guess the number between {min} and {max}. You have {maxAttempts} attempts.");

                // Loop for guessing
                while (attempts < maxAttempts)
                {
                    Console.Write($"Attempt {attempts + 1}: Enter your guess: ");
                    string input = Console.ReadLine();

                    try
                    {
                        // Convert user input to integer
                        userGuess = int.Parse(input);

                        // Check if the guess is correct
                        if (userGuess == numberToGuess)
                        {
                            Console.WriteLine("Congratulations! You guessed the correct number.");
                            break;
                        }

                        else
                        {
                            Console.WriteLine("oops! you guessed the wrong answer");
                        }

                        attempts++;
                    }

                    catch (Exception ex)
                    {
                        // Handle any other unexpected exceptions
                        Console.WriteLine($"An error occurred: {ex.Message}");
                    }
                }

                if (attempts == maxAttempts)
                {
                    Console.WriteLine($"Sorry, you've used all {maxAttempts} attempts. The correct number was {numberToGuess}.");
                }
            }
            catch (Exception ex)
            {
                // Handle any unexpected exceptions at the program level
                Console.WriteLine($"An unexpected error occurred: {ex.Message}");
            }
        }
    }
}

